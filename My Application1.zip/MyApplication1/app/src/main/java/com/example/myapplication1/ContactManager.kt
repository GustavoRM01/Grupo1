import java.util.Scanner

data class Contact(val id: Int, var name: String, var phoneNumber: String, var email: String)

class ContactManager {
    private val contacts = mutableListOf<Contact>()
    private var nextId = 1

    // Create
    fun addContact(name: String, phoneNumber: String, email: String): Contact {
        val contact = Contact(nextId++, name, phoneNumber, email)
        contacts.add(contact)
        return contact
    }

    // Read
    fun getAllContacts(): List<Contact> {
        return contacts.toList()
    }

    fun getContactById(id: Int): Contact? {
        return contacts.find { it.id == id }
    }

    // Update
    fun updateContact(id: Int, name: String, phoneNumber: String, email: String): Boolean {
        val contactIndex = contacts.indexOfFirst { it.id == id }
        if (contactIndex != -1) {
            contacts[contactIndex] = contacts[contactIndex].copy(name = name, phoneNumber = phoneNumber, email = email)
            return true
        }
        return false
    }

    // Delete
    fun deleteContact(id: Int): Boolean {
        val contact = contacts.find { it.id == id }
        if (contact != null) {
            contacts.remove(contact)
            return true
        }
        return false
    }
}

