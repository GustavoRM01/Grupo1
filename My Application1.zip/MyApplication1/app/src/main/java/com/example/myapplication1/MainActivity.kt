package com.example.myapplication


import ContactManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.myapplication1.ui.theme.MyApplication1Theme
import java.util.*


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplication1Theme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Main()
                }
            }
        }
    }
    }
@Composable
fun Main() {
    val contactManager = ContactManager()
    val scanner = Scanner(System.`in`)

    while (true) {
        println("\nEscolha uma opção:")
        println("1. Adicionar contato")
        println("2. Listar contatos")
        println("3. Atualizar contato")
        println("4. Deletar contato")
        println("5. Sair")

        when (scanner.nextInt()) {
            1 -> {
                println("Digite o nome do contato:")
                val name = scanner.next()
                println("Digite o número de telefone do contato:")
                val phoneNumber = scanner.next()
                println("Digite o email do contato:")
                val email = scanner.next()
                contactManager.addContact(name, phoneNumber, email)
                println("Contato adicionado com sucesso!")
            }
            2 -> {
                val allContacts = contactManager.getAllContacts()
                if (allContacts.isNotEmpty()) {
                    println("\nLista de contatos:")
                    allContacts.forEach {
                        println("ID: ${it.id}, Nome: ${it.name}, Telefone: ${it.phoneNumber}, Email: ${it.email}")
                    }
                } else {
                    println("Nenhum contato encontrado.")
                }
            }
            3 -> {
                println("Digite o ID do contato que deseja atualizar:")
                val id = scanner.nextInt()
                val contact = contactManager.getContactById(id)
                if (contact != null) {
                    println("Digite o novo nome do contato:")
                    val name = scanner.next()
                    println("Digite o novo número de telefone do contato:")
                    val phoneNumber = scanner.next()
                    println("Digite o novo email do contato:")
                    val email = scanner.next()
                    contactManager.updateContact(id, name, phoneNumber, email)
                    println("Contato atualizado com sucesso!")
                } else {
                    println("Contato não encontrado.")
                }
            }
            4 -> {
                println("Digite o ID do contato que deseja deletar:")
                val id = scanner.nextInt()
                val deleted = contactManager.deleteContact(id)
                if (deleted) {
                    println("Contato deletado com sucesso!")
                } else {
                    println("Contato não encontrado.")
                }
            }
            5 -> {
                println("Saindo do programa...")
                return
            }
            else -> {
                println("Opção inválida. Tente novamente.")
            }
        }
    }
}
